ApnsPHP
=======

ApnsPHP: Apple Push Notification &amp; Feedback Provider

More informations about this project on Google Code:

http://apns-php.googlecode.com/

